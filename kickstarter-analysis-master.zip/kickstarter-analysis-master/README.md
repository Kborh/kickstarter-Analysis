# hello-world

Hello All!

I am Karganleh, in data analysis is where i see myself having a career. I believe evrything is possible with commitments.
